<?php 
require 'vendor/autoload.php';

$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();

$app_id = getenv('868076');
$app_key = getenv('397a4e6f3b75712212c2');
$app_secret = getenv('b9c84e9f4413a113e9b3');
$app_cluster = getenv('ap2');


header('Content-Type: application/json');

$options = ['cluster' => $app_cluster, 'encrypted' => true];
$pusher = new Pusher\Pusher($app_key, $app_secret, $app_id, $options);

$channel = $_POST['channel_name'];
$socket_id = $_POST['socket_id'];

echo $pusher->socket_auth($channel, $socket_id);